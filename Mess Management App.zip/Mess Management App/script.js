const DATA={
 daily:{labels:['Mon','Tue','Wed','Thu','Fri','Sat','Sun'],p:[120,140,130,150,170,95,110],c:[110,125,120,140,150,90,100]},
 weekly:{labels:['W1','W2','W3','W4'],p:[780,720,850,800],c:[700,680,760,740]},
 monthly:{labels:['Jan','Feb','Mar','Apr'],p:[3000,2800,3200,3100],c:[2700,2600,2900,2850]}
};
const ctx=document.getElementById('chart').getContext('2d');
let chart;
function setRange(key){
 let d=DATA[key], w=d.p.map((v,i)=>v-d.c[i]), pct=w.map((v,i)=>Math.round(v/d.p[i]*100));
 document.getElementById('summary').innerText=`Total Wasted: ${w.reduce((a,b)=>a+b)} kg | Avg: ${Math.round(pct.reduce((a,b)=>a+b)/pct.length)}%`;
 if(chart)chart.destroy();
 chart=new Chart(ctx,{type:'bar',data:{labels:d.labels,datasets:[
  {label:'Prepared',data:d.p,backgroundColor:'rgba(37,99,235,0.4)'},
  {label:'Consumed',data:d.c,backgroundColor:'rgba(16,185,129,0.4)'},
  {label:'Wasted',data:w,backgroundColor:'rgba(239,68,68,0.4)'},
  {label:'Wastage %',data:pct,type:'line',yAxisID:'y1',borderColor:'purple'}]},
  options:{scales:{y:{beginAtZero:true},y1:{type:'linear',position:'right',beginAtZero:true,max:100}}}});
}
setRange('daily');